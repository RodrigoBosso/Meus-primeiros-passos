#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase[41];
    char frase2[41];
    //linha abaixo resulta em erro
    //nome = "Winter is coming!";
    strcpy(frase,"Winter is coming!");
    printf(frase);
    //linha abaixo resulta em erro
    //frase2=frase;
    strcpy(frase2,frase);
    printf("\n");
    printf(frase2);

    printf("\n\nA frase anterior tem %d caracteres.\n",strlen(frase));

    if(strcmp(frase,frase2)==0) printf("iguais");
    return 0;
}
