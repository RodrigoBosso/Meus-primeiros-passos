#include <stdio.h>
#include <stdlib.h>

int main()
{
    int datas[2][3];
    int i,j;
    datas[0][0]=28;
    datas[0][1]=12;
    datas[0][2]=2018;
    datas[1][0]=7;
    datas[1][1]=1;
    datas[1][2]=2019;
/*
    printf("datas:\n");
    printf("inicio: %02d/%02d/%d\n",datas[0][0],datas[0][1],datas[0][2]);
    printf("fim: %02d/%02d/%d\n",datas[1][0],datas[1][1],datas[1][2]);
*/
    for(i=0;i<2;i++){
        for(j=0;j<3;j++){
            printf("%d\t",datas[i][j]);
        }
        printf("\n");
    }

    return 0;
}
