#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase[51];
    int letras;
    //N�o � poss�vel usar o operador de atribui��o = para uma string
    //frase="Winter is coming!";

    //alternativa:
    strcpy(frase,"Winter is coming!");
    printf(frase);
    letras = strlen(frase);
    printf("\nEssa frase tem %d caracteres",letras);
    return 0;


}
