#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j;
    int datas[2][3]; //guardar duas datas, com
                     //dia, m�s e ano
    //primeira data (inicio)
    datas[0][0]=1;
    datas[0][1]=4;
    datas[0][2]=2019;

    //segunda data (fim)
    datas[1][0]=30;
    datas[1][1]=5;
    datas[1][2]=2019;

    printf("data inicio: %d/%d/%d\n",datas[0][0],datas[0][1],datas[0][2]);
    printf("data fim: %d/%d/%d\n",datas[1][0],datas[1][1],datas[1][2]);

    printf("\n");
    printf("Exibindo a matriz:\n");

    for(i=0;i<2;i++){
        for(j=0;j<3;j++){
            printf("%d\t",datas[i][j]);
        }
        printf("\n");
    }
    return 0;
}
