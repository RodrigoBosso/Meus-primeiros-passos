#include <stdio.h>
#include <stdlib.h>

int main()
{
    char nome[21];
    printf("Como vc chama, colega?\n");

    //lendo uma palavra:
    //scanf("%s",nome);

    //lendo incluindo espa�os
    //scanf("%[a-z A-Z]",nome);

    //gets(nome);
    fgets(nome,21,stdin);

    //printf("%s",nome);
    //printf(nome);


    printf("Oi, %s",nome);


    return 0;
}
