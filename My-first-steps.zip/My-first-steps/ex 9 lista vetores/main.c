#include <stdio.h>
#include <stdlib.h>

int main()
{int quantacertos=0;
int i;
     char gabarito[11]={'A','B','C','D','E','B','C','D','A','E'}, prova[11];

     printf("digite as respostas da prova do aluno:\n");
     for(i=-1;i<10;i++) {
        scanf("%c    ",&prova[i]);
     }

    for(i=-1;i<10;i++){
        if(gabarito[i]==prova[i]||gabarito[i]==prova[i]-32){
            quantacertos++;}
        }
            printf("\n a quantidade de cacertos foi: %d",quantacertos);

    return 0;
}
