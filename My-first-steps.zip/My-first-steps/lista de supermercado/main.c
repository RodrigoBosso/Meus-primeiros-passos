#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{ int v=0;//valor principal de verifica��o.
int i;// valores auxiliarespara controlole das matrizes
char nome[10][60];
int quant[10],t,n;
float valor[10];
int np=0;

for(i=0;i<10;i++){
    for(t=0;t<60;t++){
            nome[i][t]=' ';}
}

i=0;

   while(v!=3){
        printf("DIGITE UM NUMERO:\n1 Para inserir produtos \n2 Para listar produtos \n3 Para fechar o programa.\n\n numero de produtos = %d ",np);
        scanf("%d",&v);
   if (v==1){
    system("cls");
    printf("Legal voce digitou o valor 1 !\n");

          if (np==10){
                printf("Que pena, voce n�o tem mais espa�o no seu carrinho :(\n");
                system("pause");
                goto cheio;  }

    printf("Agora digite o nome do produto assim como seu valor e quantidade\n");
    printf("Digite o nome do produto:\n");
    scanf("%s",&nome[i]);
    printf("Digite o valor do produto:\n");
    scanf("%f2",&valor[i]);
    printf("Digite a quantidade de produto(s):\n");
    scanf("%d",&quant[i]);
       i++;
       np++;

   }


   if (v==2){
    system("cls");
   if(i==0){printf("N�o tem nenhum item na lista ");
   getch();}
   if(i>0){
     printf("Legal voce digitou o valor 2 !, vela a lista dos seus produtos a seguir\n");
    printf("QUANTIDADE    VALOR R$    NOME DO PRODUTO\n");
     for(t=0;t<i;t++)
        {
    printf("  %d           ",quant[t]);
    printf(" %f            ",valor[t]);
  for(n=0;n<60;n++){
        printf("%c",nome[t][n]);}
        printf("\n");

        }
    getch();
    }    }

   cheio:
  system("cls");


}
  return 0;
}
