#include <stdio.h>
#include <stdlib.h>
//#include "funcoes.h"

int funcao_hash (int chav; int tam;){

    return (chav % tam);
};

void insere(int pos, int valor, registro tabela[])
{
    int i=0;

    while(i<tam && tabela[(pos+i) % tam].status == 'o')
    {
        i++;
    }
    if(i<tam)
    {
        tabela[(pos+i) % tam].chave = valor;
        tabela[(pos+i) % tam].status = 'o';
    }
    else printf("N�o tem mais espa�o na tabela.");
}

int busca(int chave, registro tabela[])
{
    int i=0,pos = funcao_hash(chave);

    while(i<tam && tabela[(pos+i) % tam].status != 'l' && tabela[(pos+i) % tam].chave != chave) i++;
    if(i<tam && tabela[(pos+i) % tam].status !='d' && tabela[(pos+i) % tam].chave == chave)
        return (pos+i) %tam;
    else return -1;
}

void deleta(int chave, registro tabela[])
{
    int pos = busca(chave, tabela);

    if(pos != -1)
    {
        tabela[pos].status = 'd';
    }
    else printf("Valor n�o encontrado");
}


int main()
{
    registro tabela[tam];

    for(int i=0;i<tam;i++)
    {
        tabela[i].chave= -1;
        tabela[i].status = 'l';
    }

    insere(funcao_hash(16),16,tabela);
    insere(funcao_hash(23),23,tabela);
    insere(funcao_hash(41),41,tabela);
    insere(funcao_hash(25),25,tabela);
    insere(funcao_hash(39),39,tabela);


    for(int i=0;i<tam;i++)
    {
        printf("\nChave: %d || Status: %c ",tabela[i].chave, tabela[i].status);
    }

    printf("n\nResultado da busca de 41: %d\n", busca(41,tabela));

    deleta(23,tabela);

    for(int i=0;i<tam;i++)
    {
        printf("\nChave: %d || Status: %c ",tabela[i].chave, tabela[i].status);
    }


    return 0;
}
