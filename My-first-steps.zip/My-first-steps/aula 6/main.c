#include <stdio.h>
#include <stdlib.h>

int main()
{
  /*int a;
    a=11;
    while(a>10);
    {
        a++;
        printf("%d ",a);

    } return 0;*/









}
