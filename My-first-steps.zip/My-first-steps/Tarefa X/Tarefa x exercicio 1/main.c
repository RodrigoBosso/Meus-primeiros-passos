#include <stdio.h>
#include <stdlib.h>

int main()
{

int v[10];
int k=0;
int i;
//Ler valores
for (i=0;i<10;i++){
   scanf("%d",&v[i]);

}
system("cls");

//Mosta os valores
printf("esses sao os numeros do vetor em questao");

printf("%d %d %d %d %d %d %d %d %d %d",v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9]);
    return 0;
}
