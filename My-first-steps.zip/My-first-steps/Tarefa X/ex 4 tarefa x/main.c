#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Digite 8 letras para sabr quai delas sao consoantes\n");
    int i;
    char L ,V[8];
    for(i=0;i<8;i++){
    L=getch();
    V[i]=L;
    printf("%c\n",L);
    }
    system("cls");

    for(i=0;i<8;i++){
    if ((V[i]!='a'&& V[i]!='e') && (V[i]!='i' && (V[i]!='o' && V[i]!='u')))
        printf("%c ",V[i]);
    }
    return 0;
}
