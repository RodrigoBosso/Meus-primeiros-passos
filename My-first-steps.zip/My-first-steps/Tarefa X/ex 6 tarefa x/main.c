#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Declara��o de veriaveis
    int n, V[15],i,PAR[15], IMPAR[15], k;
    //Lendo o voalor e aramsenando no vetor principal
       for(i=0;i<15;i++){
       scanf("%d",&n);
       V[i]=n;
   // Atribui��o o valor lido nos Vetores Par e Impar
           if (n%2!=0) {IMPAR[i]=n;
           PAR[i]=k;
           }
           else {PAR[i]=n;
           IMPAR[i]=k;}
       }
    //Escrevendo os vetores
    printf("No vetor principal tem-se:");
       for(i=0;i<15;i++)
       printf("%d,",V[i]);
       printf("\nNo vetor PAR tem-se:");
       for(i=0;i<15;i++){
       if (PAR[i]!=k){
       printf("%d,",PAR[i]);
       }}
       printf("\nNo vetor IMPAR tem-se:");
       for(i=0;i<15;i++){
       if (IMPAR[i]!=k){
       printf("%d,",IMPAR[i]);
       }}


    return 0;
}
