#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("digite uma sequencia de numeros para descobrir a ordem inversa\n");
 int V[10],i=0;
 float n;
 for(i=0;i<10;i++){
 scanf("%f",&n);
 V[i]=n;
 }
  system("cls");
  printf("A ordem inversa sera:\n");
 for(i=9;i>-1;i--){
        if(i!=0){
        printf("%d, ",V[i]);}
        else printf("%d. ",V[i]);
        ;
 }


    return 0;
}
