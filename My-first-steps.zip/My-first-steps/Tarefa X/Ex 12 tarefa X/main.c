#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Letra ,A[30], B[30], C[30], D[30], E[30], F[30], G[30], H[30], I[30] ,J[30];
    int i;
    printf("Digite 10 nomes");
    i=0;
    do{scanf("%c, Letra");
    i++;
    A[i]=Letra

    }while (Letra!=' '|| Letra!='\n')
    for
    printf("%d",A[i])
    return 0;
}
