#include <stdio.h>
#include <stdlib.h>

int main()
{
   int N;
   printf("Digite um numero para saber se ele e par ou impar\n");
  scanf("%d",&N);
    if (N%2==0) printf("O seu numeo e PAR");
    else printf("O seu numeo e IMPAR");
}
