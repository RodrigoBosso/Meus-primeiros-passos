#include <stdio.h>
#include <stdlib.h>

int main()
{ int X, Y ,Z;
printf("DIGITA 3 VALORES PARA FORMAR LADOS DE UM TRIANGULO\n");
scanf("%d %d %d",&X,&Y,&Z);

if(X>=(Y+Z)||Y>=(X+Z)||Z>=(X+Y)) printf("NAO HA FORMACAO DE TRIANGULO");
else
    {
if (X==Y&&Y==Z) printf("O TRIANGULO FORMADO E EQUILATERO");

if (((X==Z&&X!=Y)||(X==Y&&X!=Z))||((Y==Z&&X!=Y))) printf("O TRIANGULO FORMADO SERA ISOSCELES");

if ((X!=Z&&X!=Y)&&(Y!=Z)) printf("O TRIANGULO FORMADO SERA ESCALENO");
}

    return 0;
}
