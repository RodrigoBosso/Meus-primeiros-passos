#include <stdio.h>
#include <stdlib.h>

int main()
{ char S;
float N1,N2;
printf("DIGITE O SIMBOLO DA OPERACAO QUE DESEJA REALIZAR (+ ou - ou * ou / )\n");

scanf("%c",&S);

printf("DIGITE OS VALORES DA OPERACAO QUE DESEJA REALIZAR\n");
printf("\n");
scanf("%f  %f",&N1,&N2);

printf("O SEU RESULTADO  ");
if (S=='+') printf("%f",(N1+N2));
  else if (S=='-') printf("%f",(N1-N2));
             else if (S=='*') printf("%f",(N1*N2));
                        else if (S=='/' && N2!=0) printf("%f",(N1/N2));
                                    else printf("ERRO: divisao por zero");
 else printf("ERRO:operador invalido)");
    return 1;
return 0;
}

