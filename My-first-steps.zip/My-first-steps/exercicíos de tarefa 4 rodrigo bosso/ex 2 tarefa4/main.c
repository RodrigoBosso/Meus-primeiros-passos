#include <stdio.h>
#include <stdlib.h>

int main()
{
  float A,B,C;
  printf("Digite 3 numeros \n");
  scanf("%f" "%f" "%f",&A,&B,&C);


  if (A>B&&B>C) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",A,C,(A+C)/2);
  if (A>C&&C>B) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",A,B,(A+B)/2);
  if (B>A&&A>C) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",B,C,(B+C)/2);
  if (B>C&&C>A) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",B,A,(B+A)/2);
  if (C>A&&A>B) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",C,B,(C+B)/2);
  if (C>B&&B>A) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",C,A,(C+A)/2);
  if (A==B&&B==C) printf("Numeros iguais, media =%f",A );
  if ((A==B&&B!=C)&&C>A) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",C,A,(C+A)/2);
  if ((A==B&&B!=C)&&C<A) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",A,C,(C+A)/2);

  if ((C==B&&B!=A)&&A>C) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",A,C,(C+A)/2);
  if ((C==B&&B!=A)&&A<C) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",A,C,(A+C)/2);

  if ((A==C&&B!=C)&&B>C) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",B,C,(B+A)/2);
  if ((A==C&&B!=C)&&B<C) printf("O maior numero e: %f\n o menor numero e: %f\n  a media do maior e menor e: %f",C,B,(B+A)/2);
}

