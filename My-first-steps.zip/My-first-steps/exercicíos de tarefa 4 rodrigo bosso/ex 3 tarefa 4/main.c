#include <stdio.h>
#include <stdlib.h>

int main()
{
   float N1,N2;

   printf("DIGITE 2 NOTAS (entre 0 e 10) PARA O CAUCULO DA MEDIA:\n");

   scanf("%f %f",&N1,&N2);

   if((N1+N2)/2>=6) printf("SUA MEDIA FOI:%f ,PARABENS VOCE ESTA APROVADO!",(N1+N2)/2);
   else printf("SUA MEDIA FOI:%f ,VOCE ESTA REPROVADO,ESTUDE MAIS!!",(N1+N2)/2);


    return 0;
}
