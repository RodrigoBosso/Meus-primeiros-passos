#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// fun�oes de desenho
void Desenha0  (){

printf(" ___________ \n");
    printf("|           I \n");
    printf("|         \n");
    printf("|         \n");
    printf("|        \n");
    printf("|  \n");

}

void Desenha1  (){

printf(" ___________ \n");
    printf("|           I \n");
    printf("|           O \n");
    printf("|          \n");
    printf("|          \n");
    printf("|  \n");

}

void Desenha2  (){

printf(" ___________ \n");
    printf("|           I \n");
    printf("|          \O/ \n");
    printf("|            \n");
    printf("|           \n");
    printf("|  \n");

}

void Desenha3  (){

printf(" ___________ \n");
    printf("|           I \n");
    printf("|          \\O/ \n");
    printf("|          \n");
    printf("|          \n");
    printf("|  \n");

}

void Desenha4  (){

printf(" ___________ \n");
    printf("|           I \n");
    printf("|          \\O/ \n");
    printf("|           | \n");
    printf("|          \n");
    printf("|  \n");

}

void Desenha5  (){

printf(" ___________ \n");
    printf("|           I \n");
    printf("|          \\O/ \n");
    printf("|           | \n");
    printf("|          / \n");
    printf("|  \n");

}


void Desenha6  (){

printf(" ___________ \n");
    printf("|           I \n");
    printf("|          \\O/ \n");
    printf("|           | \n");
    printf("|          /\\ \n");
    printf("|  \n");

}



//c�digo



int main()
{   int aux=0,i, V   , G=1;   // aux � para conferir qual o desenho deve ser desenhado,
                      // i � um contador para repeti�oes em for
                      //V � o auxiliar de verifica��o se uma letra existe ou n�o na palavra


    char palavra[60], L, resp[60];  // o jogo armasenar� uma palavra simples de at� 60 letras
                                    // L � a variavel que guardar� a letra digitada pelo usuario


do {
// limpando vetor resp que sera a resposta inpressa a cada jogada

for(i=0;i<60;i++){
       resp[i]=NULL;
       palavra [i]=NULL;}





  // inicio do jogo jogador 1
    printf("  Jogador 1 \nDigite uma palavra:\n");

    scanf("%s",palavra);

    system("cls");

// jogador 2 tenta descobrir as letras

    Desenha0  ();

        for(i=0;i<strlen(palavra);i++){
       resp[i]='_';
       if (palavra[i]=='-') {resp[i]='-';}
    }


 do{



    for(i=0;i<strlen(palavra);i++){
       printf("%c ",resp[i]);}
      printf("\n\n\n ");



      printf("  Jogador 2 \nDigite uma letra: ");

//Verifica��o de conteudo

setbuf(stdin, NULL);
scanf("%c",&L);

for(i=0;i<strlen(palavra);i++)
    {
        if (L ==palavra[i]){
            resp[i]=L;
                V=1;       }
        else V=0;
    }



if (V==0) { aux++;}

system("cls");

switch(aux){
case 0 :Desenha0  ();
break;
case 1 :Desenha1  ();
break;
case 2 :Desenha2  ();
break;
case 3 :Desenha3  ();
break;
case 4 :Desenha4  ();
break;
case 5 :Desenha5  ();
break;
case 6 :Desenha6  ();
break;

}

for(i=0;i<strlen(palavra);i++){
       printf("%c ",resp[i]);}
      printf("\n\n\n ");


      }while(palavra != resp  || aux < 6 );
if (aux<6) printf(" PARABENS VOCE DESCOBRIU A PALAVRA !!");
else printf("VOCE PERDEU !!");


printf("\n\n\n voce quer jogar denovo? se sim aperte 1 se n�o aperte 2\n\n");

scanf("%d",&G);

}while(G=1);

      printf("\n\n\n\n   ATE A PROXIMA  ");

    return 0;
}
