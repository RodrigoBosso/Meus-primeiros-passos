#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main()
{
  char Nhex[21],Nhexd[21];
    int decimal,i,vet[21],conta,j;
    decimal=0;
     for(i=0;i<20;i++)
     {
      vet[i]=-1;
      Nhex[i]=' ';
     }
j=0;
     printf("Digite o numero hexadecimal que voce quer converter :   ");
     scanf("%s",Nhexd);

     for(i=strlen(Nhexd)-1;i>=0;i--){

            Nhex[j]=Nhexd[i];
               j++;
               }

    for(i=0;i<20;i++){


            if (Nhex[i]=='0'){
                    vet[i]=0;}
            if (Nhex[i]=='1'){
                    vet[i]=1;}
           if (Nhex[i]=='2'){
                    vet[i]=2;}
            if (Nhex[i]=='3'){
                    vet[i]=3;}
            if (Nhex[i]=='4'){
                    vet[i]=4;}
            if (Nhex[i]=='5'){
                    vet[i]=5;}
            if (Nhex[i]=='6'){
                    vet[i]=6;}
            if (Nhex[i]=='7'){
                    vet[i]=7;}
            if (Nhex[i]=='8'){
                    vet[i]=8;}
            if (Nhex[i]=='9'){
                    vet[i]=9;}
            if (Nhex[i]=='A'||Nhex[i]=='a'){
                    vet[i]=10;}
            if (Nhex[i]=='B'||Nhex[i]=='b'){
                    vet[i]=11;}
            if (Nhex[i]=='C'||Nhex[i]=='c'){
                    vet[i]=12;}

            if (Nhex[i]=='D'||Nhex[i]=='d'){
                    vet[i]=13;}

            if (Nhex[i]=='E'||Nhex[i]=='e'){
                    vet[i]=14;}

            if (Nhex[i]=='F'||Nhex[i]=='f'){
                    vet[i]=15;}

            if (vet[i]==0||vet[i]==1||vet[i]==2||vet[i]==3||vet[i]==4||vet[i]==5||vet[i]==6||vet[i]==7||vet[i]==8||vet[i]==9||vet[i]==10||vet[i]==11||vet[i]==12||vet[i]==13||vet[i]==14||vet[i]==15)
                {

                  conta=vet[i]*pow(16,i);

                  decimal=decimal+conta;

                }

            }

     printf("\nEste e o numero correspondente em decimal:  %d\n\n",decimal);


    return 0;
}
