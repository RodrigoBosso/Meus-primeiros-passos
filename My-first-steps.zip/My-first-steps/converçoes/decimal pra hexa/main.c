#include <stdio.h>
#include <stdlib.h>

int main()
{

   int nd,conta, i, nh[21];

   printf("Digite o mero em decimal que voce quer converter para hexadecimal :   ");

   scanf("%d",&nd);

   for(i=0;i<20;i++){
   conta=nd%16;
    nd=nd/16;
    nh[i]=conta;

   }

   printf("\n\nO seu numero em hexadecimal sera :  ");

   for(i=20;i>-1;i--){

   if( nh[i]==15){printf("F");}
   if( nh[i]==14){printf("E");}
   if( nh[i]==13){printf("D");}
   if( nh[i]==12){printf("C");}
   if( nh[i]==11){printf("B");}
   if( nh[i]==10){printf("A");}
   if( nh[i]==9){printf("9");}
   if( nh[i]==8){printf("8");}
   if( nh[i]==7){printf("7");}
   if( nh[i]==6){printf("6");}
   if( nh[i]==5){printf("5");}
   if( nh[i]==4){printf("4");}
   if( nh[i]==3){printf("3");}
   if( nh[i]==2){printf("2");}
   if( nh[i]==1){printf("1");}
   if( nh[i]==0&&nh[i-1]!=0&&nh[i-2]!=0&&nh[i-3]!=0&&nh[i-4]!=0&&nh[i-5]!=0){printf("0");}

   }

    return 0;
}
