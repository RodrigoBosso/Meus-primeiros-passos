#include <stdio.h>
#include <stdlib.h>

int main()
{
int D, conversor,vet[21],i;
printf("Digite o numero em  decimal que sera convertido para binario :  ");
scanf("%d",&D);

printf("\n\nO numero digitado em binario sera:  ");

for(i=0;i<20;i++)
    {
    conversor=D%2;
    D=D/2;
    vet[i]=conversor;
    if (vet[i]==0&vet[i+1]!=0&vet[i+2]!=0&vet[i+3]!=0&vet[i+4]!=0&vet[i+5]!=0&vet[i+6]!=0||vet[i]!=1) printf("%d",vet[i]);
}


    return 0;
}
