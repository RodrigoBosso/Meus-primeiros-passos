#include <stdio.h>
#include <stdlib.h>

int main()
{
   int valor, ajuda, cont;
   char matriz[3][3], player1,player2;
   matriz[0][0]='1';
   matriz[0][1]='2';
   matriz[0][2]='3';
   matriz[1][0]='4';
   matriz[1][1]='5';
   matriz[1][2]='6';
   matriz[2][0]='7';
   matriz[2][1]='8';
   matriz[2][2]='9';
player1='k';
   cont=0;

do{
   printf("escolha se voce vai querer ser o jogador do X ou da O, digitando qual voce prefere:\n");
player1=getch("%c");;
printf("\n%c   ",player1);

}while((player1=='X'||player1=='O')||(player1=='x'||player1=='O'));

   if (player2=='O') player1='X';
   if (player2=='X') player1='O';

    printf("\nGeralmente quem escolhe O acaba ganhando ");
    system("cls");

  printf("digite o numero correspondente ao local onde voce quer come�ar:\n");
 printf("   %c  |  %c  |  %c  \n",matriz[0][0],matriz[0][1],matriz[0][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c   \n",matriz[1][0],matriz[1][1],matriz[1][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c  \n",matriz[2][0],matriz[2][1],matriz[2][2]);
  printf("      |     |       \n");


   scanf("%d",&valor);  /* player1  jogada 1 *//*
   if (valor>10 || valor<1) printf("erro tente de novo\n");
     while(valor>10 || valor<1){
        scanf("%d",&valor);
        if(valor>10 || valor<1) printf("erro tente de novo\n");
     }

        if (valor==1) matriz[0][0]=player1;
        if (valor==2) matriz[0][1]=player1;
        if (valor==3) matriz[0][2]=player1;
        if (valor==4) matriz[1][0]=player1;
        if (valor==5) matriz[1][1]=player1;
        if (valor==6) matriz[1][2]=player1;
        if (valor==7) matriz[2][0]=player1;
        if (valor==8) matriz[2][1]=player1;
        if (valor==9) matriz[2][2]=player1;
cont++;
        system("cls");
          printf("e ai como voce vai responder a essa jogada em jogador %c\n",player2);
 printf("   %c  |  %c  |  %c  \n",matriz[0][0],matriz[0][1],matriz[0][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c   \n",matriz[1][0],matriz[1][1],matriz[1][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c  \n",matriz[2][0],matriz[2][1],matriz[2][2]);
  printf("      |     |       \n");

  erro1:
       scanf("%d",&valor);  /* player2  jogada 2 *//*
   if (valor>10 || valor<1) printf("erro tente de novo\n");
     while(valor>10 || valor<1){
        scanf("%d",&valor);
        if(valor>10 || valor<1) printf("erro tente de novo\n");

     }

     if (valor==1&& matriz[0][0]!=player1 ){ matriz[0][0]=player2;}
     if (valor==1&& matriz[0][0]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==2&& matriz[0][1]!=player1 ) {matriz[0][1]=player2;}
     if (valor==2&& matriz[0][1]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==3&& matriz[0][2]!=player1 ) {matriz[0][1]=player2;}
     if (valor==3&& matriz[0][2]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==4&& matriz[1][0]!=player1 ) {matriz[1][0]=player2;}
     if (valor==4&& matriz[1][0]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==5&& matriz[1][1]!=player1 ) {matriz[1][1]=player2;}
     if (valor==5&& matriz[1][1]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==6&& matriz[1][2]!=player1 ) {matriz[1][2]=player2;}
     if (valor==6&& matriz[1][2]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==7&& matriz[2][0]!=player1 ) {matriz[2][0]=player2;}
     if (valor==7&& matriz[2][0]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==8&& matriz[2][1]!=player1 ) {matriz[2][1]=player2;}
     if (valor==8&& matriz[2][1]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==9&& matriz[2][2]!=player1 ) {matriz[2][2]=player2;}
     if (valor==9&& matriz[2][2]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
cont++;
system("cls");
          printf("e ai como voce vai responder a essa jogada em jogador %c\n",player1);
 printf("   %c  |  %c  |  %c  \n",matriz[0][0],matriz[0][1],matriz[0][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c   \n",matriz[1][0],matriz[1][1],matriz[1][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c  \n",matriz[2][0],matriz[2][1],matriz[2][2]);
  printf("      |     |       \n");


   erro2:
       scanf("%d",&valor);  /* player1  jogada 3 *//*
   if (valor>10 || valor<1) printf("erro tente de novo\n");
     while(valor>10 || valor<1){
        scanf("%d",&valor);
        if(valor>10 || valor<1) printf("erro tente de novo\n");

     }

     if (valor==1&& matriz[0][0]!=player2 ){ matriz[0][0]=player1;}
     if (valor==1&& matriz[0][0]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==2&& matriz[0][1]!=player2 ) {matriz[0][1]=player1;}
     if (valor==2&& matriz[0][1]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==3&& matriz[0][2]!=player2 ) {matriz[0][1]=player1;}
     if (valor==3&& matriz[0][2]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==4&& matriz[1][0]!=player2 ) {matriz[1][0]=player1;}
     if (valor==4&& matriz[1][0]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==5&& matriz[1][1]!=player2 ) {matriz[1][1]=player1;}
     if (valor==5&& matriz[1][1]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==6&& matriz[1][2]!=player2 ) {matriz[1][2]=player1;}
     if (valor==6&& matriz[1][2]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==7&& matriz[2][0]!=player2 ) {matriz[2][0]=player1;}
     if (valor==7&& matriz[2][0]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==8&& matriz[2][1]!=player2 ) {matriz[2][1]=player1;}
     if (valor==8&& matriz[2][1]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==9&& matriz[2][2]!=player2 ) {matriz[2][2]=player1;}
     if (valor==9&& matriz[2][2]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}


            system("cls");
          printf("e ai como voce vai responder a essa jogada em jogador %c\n",player2);
 printf("   %c  |  %c  |  %c  \n",matriz[0][0],matriz[0][1],matriz[0][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c   \n",matriz[1][0],matriz[1][1],matriz[1][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c  \n",matriz[2][0],matriz[2][1],matriz[2][2]);
  printf("      |     |       \n");


       scanf("%d",&valor);  /* player2  jogada 4 *//*
   if (valor>10 || valor<1) printf("erro tente de novo\n");
     while(valor>10 || valor<1){
        scanf("%d",&valor);
        if(valor>10 || valor<1) printf("erro tente de novo\n");

     }

     if (valor==1&& matriz[0][0]!=player1 ){ matriz[0][0]=player2;}
     if (valor==1&& matriz[0][0]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==2&& matriz[0][1]!=player1 ) {matriz[0][1]=player2;}
     if (valor==2&& matriz[0][1]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==3&& matriz[0][2]!=player1 ) {matriz[0][1]=player2;}
     if (valor==3&& matriz[0][2]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==4&& matriz[1][0]!=player1 ) {matriz[1][0]=player2;}
     if (valor==4&& matriz[1][0]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==5&& matriz[1][1]!=player1 ) {matriz[1][1]=player2;}
     if (valor==5&& matriz[1][1]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==6&& matriz[1][2]!=player1 ) {matriz[1][2]=player2;}
     if (valor==6&& matriz[1][2]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==7&& matriz[2][0]!=player1 ) {matriz[2][0]=player2;}
     if (valor==7&& matriz[2][0]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==8&& matriz[2][1]!=player1 ) {matriz[2][1]=player2;}
     if (valor==8&& matriz[2][1]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
     if (valor==9&& matriz[2][2]!=player1 ) {matriz[2][2]=player2;}
     if (valor==9&& matriz[2][2]==player1 ){printf("escolha um numero valido por favor ");
        goto erro1;}
cont++;
system("cls");
          printf("e ai como voce vai responder a essa jogada em jogador %c\n",player1);
 printf("   %c  |  %c  |  %c  \n",matriz[0][0],matriz[0][1],matriz[0][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c   \n",matriz[1][0],matriz[1][1],matriz[1][2]);
  printf(" _____|_____|_____ \n");
 printf("   %c  |  %c  |  %c  \n",matriz[2][0],matriz[2][1],matriz[2][2]);
  printf("      |     |       \n");



       scanf("%d",&valor);  /* player1  jogada 5!!! *//*
   if (valor>10 || valor<1) printf("erro tente de novo\n");
     while(valor>10 || valor<1){
        scanf("%d",&valor);
        if(valor>10 || valor<1) printf("erro tente de novo\n");

     }

     if (valor==1&& matriz[0][0]!=player2 ){ matriz[0][0]=player1;}
     if (valor==1&& matriz[0][0]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==2&& matriz[0][1]!=player2 ) {matriz[0][1]=player1;}
     if (valor==2&& matriz[0][1]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==3&& matriz[0][2]!=player2 ) {matriz[0][1]=player1;}
     if (valor==3&& matriz[0][2]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==4&& matriz[1][0]!=player2 ) {matriz[1][0]=player1;}
     if (valor==4&& matriz[1][0]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==5&& matriz[1][1]!=player2 ) {matriz[1][1]=player1;}
     if (valor==5&& matriz[1][1]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==6&& matriz[1][2]!=player2 ) {matriz[1][2]=player1;}
     if (valor==6&& matriz[1][2]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==7&& matriz[2][0]!=player2 ) {matriz[2][0]=player1;}
     if (valor==7&& matriz[2][0]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==8&& matriz[2][1]!=player2 ) {matriz[2][1]=player1;}
     if (valor==8&& matriz[2][1]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}
     if (valor==9&& matriz[2][2]!=player2 ) {matriz[2][2]=player1;}
     if (valor==9&& matriz[2][2]==player2 ){printf("escolha um numero valido por favor ");
        goto erro2;}



*/







       return 0;
}
