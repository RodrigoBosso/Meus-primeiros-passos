#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    char biN[21];
    int decimal,i,vet[21],conta;
decimal=0;
printf("Digite o numero binario que voce quer converter :   ");
    for(i=0;i<21;i++){
      vet[i]=2;
      biN[i]=' ';

    }
           scanf("%s",biN);

     for(i=20;i>-1;i--){

            if (biN[i]=='1'){
                    vet[i]=1;}
            if (biN[i]=='0'){
                    vet[i]=0;}
           if (vet[i]==1||vet[i]==0){
                conta=vet[i]*pow(2,i);
                decimal=decimal+conta;}

            }

            printf("\nEste e o numero correspondente em decimal:  %d\n\n",decimal);



    return 0;
}
