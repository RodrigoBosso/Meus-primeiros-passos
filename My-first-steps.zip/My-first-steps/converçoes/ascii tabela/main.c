1:#include <stdio.h>
   2:
   3:/* Valores distorcidos */
   4:// agudo
   5:#define D_A_ACUTE -63  // �
   6:#define D_E_ACUTE -55  // �
   7:#define D_I_ACUTE -51  // �
   8:#define D_O_ACUTE -45  // �
   9:#define D_U_ACUTE -38  // �
  10:#define D_a_ACUTE -31  // �
  11:#define D_e_ACUTE -23  // �
  12:#define D_i_ACUTE -19  // �
  13:#define D_o_ACUTE -13  // �
  14:#define D_u_ACUTE  -6  // �
  15:// circunflexo
  16:#define D_A_CIRC -62   // �
  17:#define D_E_CIRC -54   // �
  18:#define D_O_CIRC -44   // �
  19:#define D_a_CIRC -30   // �
  20:#define D_e_CIRC -22   // �
  21:#define D_o_CIRC -12   // �
  22:// grave
  23:#define D_A_GRAVE -64  // �
  24:#define D_a_GRAVE -32  // �
  25:// til
  26:#define D_A_TILDE -61  // �
  27:#define D_O_TILDE -43  // �
  28:#define D_N_TILDE -47  // �
  29:#define D_a_TILDE -29  // �
  30:#define D_o_TILDE -11  // �
  31:#define D_n_TILDE -15  // �
  32:// trema
  33:#define D_U_UML -36    // �
  34:#define D_u_UML -4     // �
  35:// cedilha
  36:#define D_C_CEDIL -57  // �
  37:#define D_c_CEDIL -25  // �
  38:
  39:/* Valores reais */
  40:// agudo
  41:#define R_A_ACUTE 181  // �
  42:#define R_E_ACUTE 144  // �
  43:#define R_I_ACUTE 214  // �
  44:#define R_O_ACUTE 224  // �
  45:#define R_U_ACUTE 233  // �
  46:#define R_a_ACUTE 160  // �
  47:#define R_e_ACUTE 130  // �
  48:#define R_i_ACUTE 161  // �
  49:#define R_o_ACUTE 162  // �
  50:#define R_u_ACUTE 163  // �
  51:// circunflexo
  52:#define R_A_CIRC 182   // �
  53:#define R_E_CIRC 210   // �
  54:#define R_O_CIRC 226   // �
  55:#define R_a_CIRC 131   // �
  56:#define R_e_CIRC 136   // �
  57:#define R_o_CIRC 147   // �
  58:// grave
  59:#define R_A_GRAVE 183  // �
  60:#define R_a_GRAVE 133  // �
  61:// til
  62:#define R_A_TILDE 199  // �
  63:#define R_O_TILDE 229  // �
  64:#define R_N_TILDE 165  // �
  65:#define R_a_TILDE 198  // �
  66:#define R_o_TILDE 228  // �
  67:#define R_n_TILDE 164  // �
  68:// trema
  69:#define R_U_UML 154    // �
  70:#define R_u_UML 129    // �
  71:// cedilha
  72:#define R_C_CEDIL 128  // �
  73:#define R_c_CEDIL 135  // �
  74:
  75:/*Fun��o que corrige distor��o de caractere constante*/
  76:char cc(char c)
  77:{
  78:    switch (c)
  79:    {
  80:        case D_A_ACUTE: return R_A_ACUTE;  // �
  81:        case D_E_ACUTE: return R_E_ACUTE;  // �
  82:        case D_I_ACUTE: return R_I_ACUTE;  // �
  83:        case D_O_ACUTE: return R_O_ACUTE;  // �
  84:        case D_U_ACUTE: return R_U_ACUTE;  // �
  85:        case D_a_ACUTE: return R_a_ACUTE;  // �
  86:        case D_e_ACUTE: return R_e_ACUTE;  // �
  87:        case D_i_ACUTE: return R_i_ACUTE;  // �
  88:        case D_o_ACUTE: return R_o_ACUTE;  // �
  89:        case D_u_ACUTE: return R_u_ACUTE;  // �
  90:        case D_A_CIRC:  return R_A_CIRC;   // �
  91:        case D_E_CIRC:  return R_E_CIRC;   // �
  92:        case D_O_CIRC:  return R_O_CIRC;   // �
  93:        case D_a_CIRC:  return R_a_CIRC;   // �
  94:        case D_e_CIRC:  return R_e_CIRC;   // �
  95:        case D_o_CIRC:  return R_o_CIRC;   // �
  96:        case D_A_GRAVE: return R_A_GRAVE;  // �
  97:        case D_a_GRAVE: return R_a_GRAVE;  // �
  98:        case D_A_TILDE: return R_A_TILDE;  // �
  99:        case D_O_TILDE: return R_O_TILDE;  // �
 100:        case D_N_TILDE: return R_N_TILDE;  // �
 101:        case D_a_TILDE: return R_a_TILDE;  // �
 102:        case D_o_TILDE: return R_o_TILDE;  // �
 103:        case D_n_TILDE: return R_n_TILDE;  // �
 104:        case D_U_UML:   return R_U_UML;    // �
 105:        case D_u_UML:   return R_u_UML;    // �
 106:        case D_C_CEDIL: return R_C_CEDIL;  // �
 107:        case D_c_CEDIL: return R_c_CEDIL;  // �
 108:        default:        return c;
 109:    }
 110:}
 111:
 112:int main(void)
 113:{
 114:    int i;
 115:    char c;
 116:    char vogal[5] = {'a', 'e', 'i', 'o', 'u'};
 117:    char agudo[10] = {'�', '�', '�', '�', '�', '�', '�', '�', '�', '�'};
 118:    char circunflexo[6] = {'�', '�', '�', '�', '�', '�'};
 119:    char grave[2] = {'�', '�'};
 120:    char til[6] = {'�', '�', '�', '�', '�', '�'};
 121:    char trema[2] = {'�', '�'};
 122:    char cedilha[2] = {'�', '�'};
 123:
 124:    for (i = 0; i < 5; i++)
 125:        printf("Real:%c Distorcido:%c %3d\n", cc(vogal[i]), vogal[i], vogal[i]);
 126:    putchar('\n');
 127:
 128:    for (i = 0; i < 10; i++)
 129:        printf("Real:%c Distorcido:%c %3d\n", cc(agudo[i]), agudo[i], agudo[i]);
 130:    putchar('\n');
 131:
 132:    for (i = 0; i < 6; i++)
 133:        printf("Real:%c Distorcido:%c %3d\n", cc(circunflexo[i]), circunflexo[i], circunflexo[i]);
 134:    putchar('\n');
 135:
 136:    for (i = 0; i < 2; i++)
 137:        printf("Real:%c Distorcido:%c %3d\n", cc(grave[i]), grave[i], grave[i]);
 138:    putchar('\n');
 139:
 140:    for (i = 0; i < 6; i++)
 141:        printf("Real:%c Distorcido:%c %3d\n", cc(til[i]), til[i], til[i]);
 142:    putchar('\n');
 143:
 144:    for (i = 0; i < 2; i++)
 145:        printf("Real:%c Distorcido:%c %3d\n", cc(trema[i]), trema[i], trema[i]);
 146:    putchar('\n');
 147:
 148:    for (i = 0; i < 2; i++)
 149:        printf("Real:%c Distorcido:%c %3d\n", cc(cedilha[i]), cedilha[i], cedilha[i]);
 150:    putchar('\n');
 151:
 152:    c = getchar();
 153:    printf("Lido:%c Real:%c\n", c, cc(c));
 154:
 155:    return 0;
 156:}
