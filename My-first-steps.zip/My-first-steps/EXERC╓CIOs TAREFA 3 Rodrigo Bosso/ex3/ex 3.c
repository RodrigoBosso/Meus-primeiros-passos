
int main()
{

//int conta; npessoas;
//erro ao usar ; ao inv�z se , na separa��o de nomenclatura de veriaveis, e o numero da conta pode ser numero quebrado,
 //al�m de quando for trabalhar com a diviz�o dodas as variaveis tem de ser do mesmo estilo.
float conta,npessoas;
//float valor pp;
//erro ao declarar a variavel, pois o space n�o � um caractere v�lido, o correto seria _:
float valor_pp;
//printf(digite o valor da conta e o numero de pessoas);
//erro por n�o colocar "" dentro do () do comando printf
printf("digite o valor da conta e o numero de pessoas\n");
//scanf(�%f %f�, npessoas, conta);

//erro de no comando scanf , falta do & e erro na sintaxe tamb�m
scanf("%f",&npessoas);

//o programador esqueceu de pedir para digitar o valor da conta
printf("digite o valor da conta\n");
scanf("%f",&conta);

//valor pp=conta%npessoas;
/*como ocorreu mudan�a na nomenclatura da variavel tem de ocorrer outra mudan�a aqui, alem das opera�oes invalidas para int com float,
e ainda o erro de % ao inv�s de diviz�o (/)*/
valor_pp=conta/npessoas;
//print(�valor por pessoa: %f�, valor)
//Erro em sintaxe tanto no comando printf, qanto na indentifica��o da variavel quanto na falta do ;
printf("valor por pessoa:%f", valor_pp);

}

