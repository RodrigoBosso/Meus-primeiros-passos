#include <stdio.h>
#include <stdlib.h>

int main(){
   int N;
    //esse programa inverte um numero de 3 d�gitos  que o usu�rio ir� digitar

    printf("DIGITE SEU NUMERO:\n");

    scanf("%i",&N);
    printf("seu numero invertido sera :");
    printf("%i",(N%10)*100+(N%100-N%10)+N/100);

}
