
#include <stdlib.h>
#include <stdio.h>

int main()
{ float x,y;
printf("esse programa caucula a diferen�a emtre mil e um numero que sera digitado pelo usurio \n");
printf("DIGITE UM NUMERO ENTRE 0 E 1000:\n");
   scanf("%f",&x);
 y=1000-x;
system("cls");
printf("O RESULTADO OBTIDO FOI %f",y);
}
