#include <stdio.h>
#include <stdlib.h>

int fatorial(int x)
 {
     int res=1;
     while (x>1){
        res=res*x;
        x--;
     }
return res;

 }
int main()
{
   int y;
   printf("digite um numero para saber o seu fatorial\n");
   scanf("%d",&y);
   y=fatorial(y);
   printf("\n o fatorial desse numero sera %d",y);



    return 0;
}
