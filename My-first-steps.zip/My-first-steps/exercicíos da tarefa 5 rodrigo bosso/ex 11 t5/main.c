#include <stdio.h>
#include <stdlib.h>

int main()
{
int A, B, C;

scanf("%d",&A);
B=2;
 C=0;
    if (A/B==1)
        {
    printf("%d e primo", A);
    while(A>=B){
   if (A%B!=0)
    B=B+1;
    C=C+B;
}
}
if (A%C!=0) printf("%d e nao primo", A);
}
