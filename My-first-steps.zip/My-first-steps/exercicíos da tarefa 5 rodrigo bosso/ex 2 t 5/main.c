#include <stdio.h>
#include <stdlib.h>

int main()
{
   int n;
   printf("ESSES SAO OS MULTIPLOS DE 3, QUE VIVEM ENTRE O 0 E O 1000!!!\n\n");
    n=0;
    while(n<999)
    {
        n=n+3;
        printf("%d ",n);
        }
}
