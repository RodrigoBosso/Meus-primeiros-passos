#include <stdio.h>
#include <stdlib.h>

int main()
{
  int n;
    n=0;
    while(n<1000)
    {
        n++;
        printf("%d ",n);
        }
    return 0;

    }

