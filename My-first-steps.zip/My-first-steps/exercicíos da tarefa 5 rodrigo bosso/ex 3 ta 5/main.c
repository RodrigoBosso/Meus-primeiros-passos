#include <stdio.h>
#include <stdlib.h>

int main()

{
   int n,s;
   printf("ESSES SAO OS MULTIPLOS DE 3, QUE VIVEM ENTRE O 0 E O 1000!!!\n\n");
    n=0;
    s=0;
    while(n<999)
    {
        n=n+3;
        s=n+s;
        printf("%d ",n);
        }

printf("\n \n ESSA E A SOMA DOS MULTIPLOS DE 3 QUE ESTAO ENTRE  0 E O 1000 : SOMA =%d !!!",s);
return 0;
}
