
#include <stdio.h>
#include <stdlib.h>

int main()
{
   int x, res;

   printf("Digite um numero natural e descubra a menor potencia de dois que seja maior que o numero que voce digitou:\n");
res=1;
   scanf("%d",&x );

  for(;x>0;x--) {

    res=res*2;}
   }




printf("a menor potencia de 2 que e maior que seu numero e %d", res );
}
