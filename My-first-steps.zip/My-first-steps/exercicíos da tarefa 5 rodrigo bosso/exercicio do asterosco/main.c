#include <stdio.h>
#include <stdlib.h>

int main()
{
    int X=0, Y=0;
char C;

    C=getch();

   while(C='w')
    {
    Y=Y-1;
    }
    while(C='s')
    {
    Y=Y+1;
    }
        while(C='d')
    {
    X=X+1;
    }
        while(C='a')
    {
    X=X-1;
    }
    while (Y<=10)
{
    printf("\n");
    Y=Y+1;
}
    while (X<=10)
    {
        printf(" ");
        X=X+1;
    }


printf("*");
}
