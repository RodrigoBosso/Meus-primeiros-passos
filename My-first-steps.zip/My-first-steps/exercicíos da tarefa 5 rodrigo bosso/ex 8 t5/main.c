#include <stdio.h>
#include <stdlib.h>

int main()
{
int N,K,H;
H=0;
N=0;
K=0;
printf("ESSES SAO OS NUMEROS MULTIPLOS DE 3 E DE 5:\n\n");

while(N<999)

{
 N=3*(K+1);
 K=K+1;

 printf("%d; ", N);

        while(H<N && (H+5)<(N+3))
             { H=H+5;

               if (H!=N) printf("%d; ", H);

              }
}

return 0;
}

//  if (N!=H)
//   if (N!=H)


