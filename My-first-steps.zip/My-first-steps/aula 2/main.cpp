/*#include <iostream>
#include <stdlib.h>
#include <stdio.h>

int main()
{
    Hoje teve a passagem
    do pseudo c�digo para linguagem C

    float n,x,h,r;

    n=5;
    x=n/3;

    printf("%f",n);
    printf("\n");
    printf("%f\n",x);
    scanf("%f",&h);
    r=n+(h*3)-x;

    printf("%f",r);
}

*/
